package com.code.entity;

public enum Role {//An enum (short for enumeration) in Java is a special data type that represents a fixed set of constants.
	//It is used when we want to restrict a variable to take only predefined values.
			ADMIN,
			CUSTOMER
}
